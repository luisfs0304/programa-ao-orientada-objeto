/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author luis.albuquerque
 */

import com.mycompany.conexaobd.BDConnection;
import java.sql.Connection;

public class Main {

    public static void main(String[] args) {

        try {

            // Cria o objeto de conexão
            BDConnection bdConnection = new BDConnection();

            // Obtém a conexão
            Connection conexao = bdConnection.obterConexao();

            // Verifica se conectou
            if (conexao != null) {
                System.out.println("Conexão realizada com sucesso!");
            } else {
                System.out.println("Falha na conexão.");
            }

        } catch (Exception e) {

            System.out.println("Erro: " + e.getMessage());
        }
    }
}