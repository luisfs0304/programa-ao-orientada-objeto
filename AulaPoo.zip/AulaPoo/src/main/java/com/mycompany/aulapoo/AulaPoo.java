/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.aulapoo;

/**
 *
 * @author luis.albuquerque
 */
public class AulaPoo {

    public static void main(String[] args) {
        // Informações via construtor
    Pessoa p1 = new Pessoa("ronaldo", 40);
    p1.mostrarDados();

    // Informações via encapsulamento - setters
    Pessoa p2 = new Pessoa();
    p2.setNome("virginia");
    p2.setIdade(30);
    p2.mostrarDados();

    Funcionario f1 = new Funcionario("virginia", 35, 2800.00);
    f1.mostrarDados();

    ChefeDeDepartamento cd = new ChefeDeDepartamento("Luis", 60, 5000.00, "RH");
    cd.mostrarDados();
}}
