
package ucb.estudo.modelo;


public class Pessoa {
    private String nome ;
    private double altura;
    private String cpf;
    private int peso ;
    private int Idade;
    
    
    public Pessoa(){
    
    }
    
    public Pessoa(String nome,String cpf, double altura, int peso , int Idade){
        
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    
     public void setnome(String nome) {
        this.nome = nome;
    }
     
    public void setIdade(String nome) {
        this.nome = nome;
    }
    
    
    public String getIdade() {
        return nome;
    }

    /**
     * @param Idade the nome to set
     */
    public void setIdade(int Idade) {
        this.Idade = Idade;
    }


    /**
     * @return the altura
     */
    public double getAltura() {
        return altura;
    }

    /**
     * @param altura the altura to set
     */
    public void setAltura(double altura) {
        this.altura = altura;
    }

    /**
     * @return the cpf
     */
    public String getCpf() {
        return cpf;
    }

    /**
     * @param cpf the cpf to set
     */
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    /**
     * @return the peso
     */
    public int getPeso() {
        return peso;
    }

    /**
     * @param peso the peso to set
     */
    public void setPeso(int peso) {
        this.peso = peso;
    }
    public void exibirIMC(){
        double imc = peso / (altura * altura);
         System.out.println("o seu " + imc );
    }
    
}
