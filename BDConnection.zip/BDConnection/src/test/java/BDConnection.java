import java.sql.Connection;
import java.sql.DriverManager;

public class BDConnection {

    private static final String URL = "jdbc:mysql://localhost:3307/biblioteca";
    private static final String Usuario = "root";
    private static final String Senha = "catolica";

    public Connection getConnection() throws Exception {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection connection = DriverManager.getConnection(URL, Usuario, Senha);
            System.out.println("Conexão com o banco de dados estabelecida com sucesso!");

            return connection;

        } catch (Exception e) {
            throw new Exception("Erro ao conectar ao banco de dados", e);
        }
    }
}