package com.mycompany.aulapoo;

public class Carro {
    private String placa;
    private String modelo;
    private String cor;
    private String chassi;

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }
}
