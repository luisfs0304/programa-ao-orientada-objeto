/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.aula4;

import ucb.estudo.modelo.Pessoa;

/**
 *
 * @author luis.albuquerque
 */
public class Aula4 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        
            Pessoa p1 = new Pessoa();
                p1.setNome("luis felipe");
                 p1.setIdade();

        System.out.println("nome:" + p1.getNome() + " sua idade é:" + p1.getIdade());
        p1.getNome();

        pessoa1 p2 = new pessoa1("Joao silva", 60);
        System.out.println("Nome: " + p2.getNome() + " sua idade é:" + p2.getIdade());

        Calculadora c = new Calculadora();
        c.somar(p1.getIdade(), p2.getIdade());

        System.out.println("A soma das idades é " + c.somar(p1.getIdade(), p2.getIdade()));

        System.out.println("Soma de dois numeros: " + Calculadora.somar1(65.7, 88));

        double[] notas = {10.1, 8.2, 5.2, 7.2, 11.2, 27.1};
        System.out.println("media dos valores é:" + Calculadora.calcularMedia(notas));
    }
    
   
    
}

