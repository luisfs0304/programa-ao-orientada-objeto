
package com.mycompany.aula4;


public class carro {
    private String placa;
    private String modelo;
    private String cor;
    private String chassi;      
            }
