import java.lang.reflect.Field;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    private static LivroController livroController;
    private static LeitorController leitorController;
    private static EmprestimoController emprestimoController;
    private static Scanner scanner;

    public static void main(String[] args) {
        iniciarSistema();
    }

    public static void iniciarSistema() {
        scanner = new Scanner(System.in);
        livroController = new LivroController();
        leitorController = new LeitorController();
        emprestimoController = new EmprestimoController();
        
        // Compartilha o mesmo Scanner com todos os controllers via Reflection
        compartilharScanner(livroController);
        compartilharScanner(leitorController);
        compartilharScanner(emprestimoController);
        
        // Passa as referências necessárias para o controller de empréstimos rodar as validações
        emprestimoController.setControllers(livroController, leitorController);

        int opcao;

        do {
            limparTela();
            exibirMenuPrincipal();
            opcao = lerOpcao();

            switch (opcao) {
                case 1:
                    menuLivros();
                    break;
                case 2:
                    menuLeitores();
                    break;
                case 3:
                    menuEmprestimos();
                    break;
                case 4:
                    exibirSobreSistema();
                    break;
                case 0:
                    exibirCabecalho("Encerrando Sistema");
                    System.out.println("Sistema finalizado com sucesso.");
                    break;
                default:
                    System.out.println("Opcao invalida. Tente novamente.");
                    pausar();
                    break;
            }
        } while (opcao != 0);

        scanner.close();
    }

    public static void exibirMenuPrincipal() {
        exibirCabecalho("Sistema de Biblioteca");
        System.out.println("1 - Gerenciar Livros");
        System.out.println("2 - Gerenciar Leitores");
        System.out.println("3 - Gerenciar Emprestimos");
        System.out.println("4 - Sobre o Sistema");
        System.out.println("0 - Sair");
        System.out.print("Escolha uma opcao: ");
    }

    public static void menuLivros() {
        int opcao;
        do {
            limparTela();
            exibirCabecalho("Gerenciar Livros");
            System.out.println("1 - Cadastrar livro");
            System.out.println("2 - Listar livros");
            System.out.println("3 - Buscar livro");
            System.out.println("4 - Atualizar livro");
            System.out.println("5 - Excluir livro");
            System.out.println("0 - Voltar");
            System.out.print("Escolha uma opcao: ");
            opcao = lerOpcao();

            switch (opcao) {
                case 1:
                    limparTela();
                    exibirCabecalho("Cadastrar Livro");
                    livroController.cadastrarLivro();
                    pausar();
                    break;
                case 2:
                    limparTela();
                    exibirCabecalho("Listar Livros");
                    livroController.listarLivros();
                    pausar();
                    break;
                case 3:
                    limparTela();
                    exibirCabecalho("Buscar Livro");
                    livroController.buscarLivro();
                    pausar();
                    break;
                case 4:
                    limparTela();
                    exibirCabecalho("Atualizar Livro");
                    livroController.atualizarLivro();
                    pausar();
                    break;
                case 5:
                    limparTela();
                    exibirCabecalho("Excluir Livro");
                    livroController.excluirLivro();
                    pausar();
                    break;
                case 0:
                    System.out.println("Retornando ao menu principal...");
                    break;
                default:
                    System.out.println("Opcao invalida. Tente novamente.");
                    pausar();
                    break;
            }
        } while (opcao != 0);
    }

    public static void menuLeitores() {
        int opcao;
        do {
            limparTela();
            exibirCabecalho("Gerenciar Leitores");
            System.out.println("1 - Cadastrar leitor");
            System.out.println("2 - Listar leitores");
            System.out.println("3 - Buscar leitor");
            System.out.println("4 - Atualizar leitor");
            System.out.println("5 - Excluir leitor");
            System.out.println("0 - Voltar");
            System.out.print("Escolha uma opcao: ");
            opcao = lerOpcao();

            switch (opcao) {
                case 1:
                    limparTela();
                    exibirCabecalho("Cadastrar Leitor");
                    leitorController.cadastrarLeitor();
                    pausar();
                    break;
                case 2:
                    limparTela();
                    exibirCabecalho("Listar Leitores");
                    leitorController.listarLeitores();
                    pausar();
                    break;
                case 3:
                    limparTela();
                    exibirCabecalho("Buscar Leitor");
                    leitorController.buscarLeitor();
                    pausar();
                    break;
                case 4:
                    limparTela();
                    exibirCabecalho("Atualizar Leitor");
                    leitorController.atualizarLeitor();
                    pausar();
                    break;
                case 5:
                    limparTela();
                    exibirCabecalho("Excluir Leitor");
                    leitorController.excluirLeitor();
                    pausar();
                    break;
                case 0:
                    System.out.println("Retornando ao menu principal...");
                    break;
                default:
                    System.out.println("Opcao invalida. Tente novamente.");
                    pausar();
                    break;
            }
        } while (opcao != 0);
    }

    public static void menuEmprestimos() {
        int opcao;
        do {
            limparTela();
            exibirCabecalho("Gerenciar Emprestimos");
            System.out.println("1 - Registrar emprestimo");
            System.out.println("2 - Listar emprestimos");
            System.out.println("3 - Renovar emprestimo");
            System.out.println("4 - Registrar devolucao");
            System.out.println("5 - Listar emprestimos ativos");
            System.out.println("0 - Voltar");
            System.out.print("Escolha uma opcao: ");
            opcao = lerOpcao();

            switch (opcao) {
                case 1:
                    limparTela();
                    exibirCabecalho("Registrar Emprestimo");
                    emprestimoController.registrarEmprestimo();
                    pausar();
                    break;
                case 2:
                    limparTela();
                    exibirCabecalho("Listar Emprestimos");
                    emprestimoController.listarEmprestimos();
                    pausar();
                    break;
                case 3:
                    limparTela();
                    exibirCabecalho("Renovar Emprestimo");
                    emprestimoController.renovarEmprestimo();
                    pausar();
                    break;
                case 4:
                    limparTela();
                    exibirCabecalho("Registrar Devolucao");
                    emprestimoController.registrarDevolucao();
                    pausar();
                    break;
                case 5:
                    limparTela();
                    exibirCabecalho("Emprestimos Ativos");
                    emprestimoController.listarEmprestimosAtivos();
                    pausar();
                    break;
                case 0:
                    System.out.println("Retornando ao menu principal...");
                    break;
                default:
                    System.out.println("Opcao invalida. Tente novamente.");
                    pausar();
                    break;
            }
        } while (opcao != 0);
    }

    public static void exibirSobreSistema() {
        limparTela();
        exibirCabecalho("Sobre o Sistema");
        System.out.println("Sistema de Gestao de Acervo e Emprestimos.");
        System.out.println("Projeto academico desenvolvido em Java.");
        System.out.println("Modulos: Livros, Leitores e Emprestimos.");
        pausar();
    }

    public static int lerOpcao() {
        while (true) {
            String entrada = scanner.nextLine();
            try {
                return Integer.parseInt(entrada);
            } catch (NumberFormatException e) {
                System.out.print("Entrada invalida. Digite um numero: ");
            }
        }
    }

    public static void pausar() {
        System.out.println();
        System.out.print("Pressione Enter para continuar...");
        scanner.nextLine();
    }

    public static void exibirCabecalho(String titulo) {
        System.out.println("========================================");
        System.out.println(titulo);
        System.out.println("========================================");
    }

    public static void limparTela() {
        for (int i = 0; i < 20; i++) {
            System.out.println();
        }
    }

    public static void compartilharScanner(Object controller) {
        try {
            Field campoScanner = controller.getClass().getDeclaredField("scanner");
            campoScanner.setAccessible(true);
            campoScanner.set(controller, scanner);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            // Ignora se o campo de injeção falhar
        }
    }
}

// ==========================================
// CLASSES DE MODELO (ENTIDADES)
// ==========================================

class Livro {
    private int id;
    private String titulo;
    private String autor;
    private boolean disponivel;

    public Livro(int id, String titulo, String autor) {
        this.id = id;
        this.titulo = titulo;
        this.autor = autor;
        this.disponivel = true;
    }

    public int getId() { return id; }
    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }
    public String getAutor() { return autor; }
    public void setAutor(String autor) { this.autor = autor; }
    public boolean isDisponivel() { return disponivel; }
    public void setDisponivel(boolean disponivel) { this.disponivel = disponivel; }

    @Override
    public String toString() {
        return "ID: " + id + " | Titulo: " + titulo + " | Autor: " + autor + " | Status: " + (disponivel ? "Disponivel" : "Emprestado");
    }
}

class Leitor {
    private int id;
    private String nome;

    public Leitor(int id, String nome) {
        this.id = id;
        this.nome = nome;
    }

    public int getId() { return id; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    @Override
    public String toString() {
        return "ID: " + id + " | Nome: " + nome;
    }
}

class Emprestimo {
    private int id;
    private Livro livro;
    private Leitor leitor;
    private LocalDate dataEmprestimo;
    private LocalDate dataDevolucao;
    private boolean ativo;

    public Emprestimo(int id, Livro livro, Leitor leitor) {
        this.id = id;
        this.livro = livro;
        this.leitor = leitor;
        this.dataEmprestimo = LocalDate.now();
        this.dataDevolucao = LocalDate.now().plusDays(7); // 7 dias de prazo inicial
        this.ativo = true;
    }

    public int getId() { return id; }
    public Livro getLivro() { return livro; }
    public Leitor getLeitor() { return leitor; }
    public LocalDate getDataDevolucao() { return dataDevolucao; }
    public void setDataDevolucao(LocalDate dataDevolucao) { this.dataDevolucao = dataDevolucao; }
    public boolean isAtivo() { return ativo; }
    public void setAtivo(boolean ativo) { this.ativo = ativo; }

    @Override
    public String toString() {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        return "ID Emprestimo: " + id + 
               "\n -> Livro: " + livro.getTitulo() + " (ID: " + livro.getId() + ")" +
               "\n -> Leitor: " + leitor.getNome() + " (ID: " + leitor.getId() + ")" +
               "\n -> Data de Emprestimo: " + dataEmprestimo.format(fmt) +
               "\n -> Prazo de Devolucao: " + dataDevolucao.format(fmt) +
               "\n -> Status: " + (ativo ? "ATIVO" : "DEVOLVIDO") + "\n----------------------------------------";
    }
}

// ==========================================
// CONTROLADORES (LOGICA DE NEGOCIO)
// ==========================================

class LivroController {
    private Scanner scanner; // Injetado via Reflection
    private List<Livro> listaLivros = new ArrayList<>();
    private int proximoId = 1;

    public List<Livro> getListaLivros() { return listaLivros; }

    public Livro buscarPorId(int id) {
        for (Livro l : listaLivros) {
            if (l.getId() == id) return l;
        }
        return null;
    }

    public void cadastrarLivro() {
        System.out.print("Digite o titulo do livro: ");
        String titulo = scanner.nextLine();
        System.out.print("Digite o autor do livro: ");
        String autor = scanner.nextLine();

        Livro novoLivro = new Livro(proximoId++, titulo, autor);
        listaLivros.add(novoLivro);
        System.out.println("Livro cadastrado com sucesso! ID gerado: " + novoLivro.getId());
    }

    public void listarLivros() {
        if (listaLivros.isEmpty()) {
            System.out.println("Nenhum livro cadastrado.");
            return;
        }
        for (Livro l : listaLivros) {
            System.out.println(l);
        }
    }

    public void buscarLivro() {
        System.out.print("Digite o ID do livro que busca: ");
        int id = lerInteiro();
        Livro livro = buscarPorId(id);

        if (livro != null) {
            System.out.println("\nResultado da busca:");
            System.out.println(livro);
        } else {
            System.out.println("Livro com ID " + id + " nao encontrado.");
        }
    }

    public void atualizarLivro() {
        System.out.print("Digite o ID do livro que deseja atualizar: ");
        int id = lerInteiro();
        Livro livro = buscarPorId(id);

        if (livro != null) {
            System.out.print("Digite o novo titulo (ou pressione Enter para manter o atual): ");
            String novoTitulo = scanner.nextLine();
            if (!novoTitulo.trim().isEmpty()) livro.setTitulo(novoTitulo);

            System.out.print("Digite o novo autor (ou pressione Enter para manter o atual): ");
            String novoAutor = scanner.nextLine();
            if (!novoAutor.trim().isEmpty()) livro.setAutor(novoAutor);

            System.out.println("Livro atualizado com sucesso!");
        } else {
            System.out.println("Livro nao encontrado.");
        }
    }

    public void excluirLivro() {
        System.out.print("Digite o ID do livro que deseja excluir: ");
        int id = lerInteiro();
        Livro livro = buscarPorId(id);

        if (livro != null) {
            if (!livro.isDisponivel()) {
                System.out.println("Nao e possivel excluir um livro que esta emprestado no momento!");
                return;
            }
            listaLivros.remove(livro);
            System.out.println("Livro removido do acervo com sucesso.");
        } else {
            System.out.println("Livro nao encontrado.");
        }
    }

    private int lerInteiro() {
        while (true) {
            try {
                return Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.print("Por favor, digite um ID numerico valido: ");
            }
        }
    }
}

class LeitorController {
    private Scanner scanner; // Injetado via Reflection
    private List<Leitor> listaLeitores = new ArrayList<>();
    private int proximoId = 1;

    public List<Leitor> getListaLeitores() { return listaLeitores; }

    public Leitor buscarPorId(int id) {
        for (Leitor l : listaLeitores) {
            if (l.getId() == id) return l;
        }
        return null;
    }

    public void cadastrarLeitor() {
        System.out.print("Digite o nome do leitor: ");
        String nome = scanner.nextLine();

        Leitor novoLeitor = new Leitor(proximoId++, nome);
        listaLeitores.add(novoLeitor);
        System.out.println("Leitor cadastrado com sucesso! ID gerado: " + novoLeitor.getId());
    }

    public void listarLeitores() {
        if (listaLeitores.isEmpty()) {
            System.out.println("Nenhum leitor cadastrado.");
            return;
        }
        for (Leitor l : listaLeitores) {
            System.out.println(l);
        }
    }

    public void buscarLeitor() {
        System.out.print("Digite o ID do leitor: ");
        int id = lerInteiro();
        Leitor leitor = buscarPorId(id);

        if (leitor != null) {
            System.out.println(leitor);
        } else {
            System.out.println("Leitor nao encontrado.");
        }
    }

    public void atualizarLeitor() {
        System.out.print("Digite o ID do leitor: ");
        int id = lerInteiro();
        Leitor leitor = buscarPorId(id);

        if (leitor != null) {
            System.out.print("Digite o novo nome: ");
            String novoNome = scanner.nextLine();
            if (!novoNome.trim().isEmpty()) {
                leitor.setNome(novoNome);
                System.out.println("Leitor alterado com sucesso!");
            }
        } else {
            System.out.println("Leitor nao encontrado.");
        }
    }

    public void excluirLeitor() {
        System.out.print("Digite o ID do leitor a ser removido: ");
        int id = lerInteiro();
        Leitor leitor = buscarPorId(id);

        if (leitor != null) {
            listaLeitores.remove(leitor);
            System.out.println("Leitor deletado com sucesso.");
        } else {
            System.out.println("Leitor nao encontrado.");
        }
    }

    private int lerInteiro() {
        while (true) {
            try {
                return Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.print("Digite um valor numerico valido: ");
            }
        }
    }
}

class EmprestimoController {
    private Scanner scanner; // Injetado via Reflection
    private List<Emprestimo> listaEmprestimos = new ArrayList<>();
    private LivroController livroCtrl;
    private LeitorController leitorCtrl;
    private int proximoId = 1;

    public void setControllers(LivroController lCtrl, LeitorController leCtrl) {
        this.livroCtrl = lCtrl;
        this.leitorCtrl = leCtrl;
    }

    private Emprestimo buscarPorId(int id) {
        for (Emprestimo e : listaEmprestimos) {
            if (e.getId() == id) return e;
        }
        return null;
    }

    public void registrarEmprestimo() {
        System.out.print("Digite o ID do Leitor: ");
        int idLeitor = lerInteiro();
        Leitor leitor = leitorCtrl.buscarPorId(idLeitor);

        if (leitor == null) {
            System.out.println("Erro: Leitor nao encontrado!");
            return;
        }

        System.out.print("Digite o ID do Livro: ");
        int idLivro = lerInteiro();
        Livro livro = livroCtrl.buscarPorId(idLivro);

        if (livro == null) {
            System.out.println("Erro: Livro nao encontrado!");
            return;
        }

        if (!livro.isDisponivel()) {
            System.out.println("Erro: Este livro ja esta emprestado para outra pessoa no momento!");
            return;
        }

        livro.setDisponivel(false);
        Emprestimo novoEmprestimo = new Emprestimo(proximoId++, livro, leitor);
        listaEmprestimos.add(novoEmprestimo);
        System.out.println("Emprestimo gerado com sucesso! ID do registro: " + novoEmprestimo.getId());
    }

    public void listarEmprestimos() {
        if (listaEmprestimos.isEmpty()) {
            System.out.println("Nenhum registro de emprestimo no historico.");
            return;
        }
        for (Emprestimo e : listaEmprestimos) {
            System.out.println(e);
        }
    }

    public void listarEmprestimosAtivos() {
        boolean temAtivos = false;
        for (Emprestimo e : listaEmprestimos) {
            if (e.isAtivo()) {
                System.out.println(e);
                temAtivos = true;
            }
        }
        if (!temAtivos) {
            System.out.println("Nao ha emprestimos pendentes/ativos no momento.");
        }
    }

    public void renovarEmprestimo() {
        System.out.print("Digite o ID do Emprestimo que deseja renovar: ");
        int id = lerInteiro();
        Emprestimo emp = buscarPorId(id);

        if (emp != null && emp.isAtivo()) {
            emp.setDataDevolucao(emp.getDataDevolucao().plusDays(7)); // Soma mais 7 dias de prazo
            System.out.println("Emprestimo renovado com sucesso! Novo prazo: " + emp.getDataDevolucao());
        } else {
            System.out.println("Emprestimo ativo nao encontrado.");
        }
    }

    public void registrarDevolucao() {
        System.out.print("Digite o ID do Emprestimo a ser devolvido: ");
        int id = lerInteiro();
        Emprestimo emp = buscarPorId(id);

        if (emp != null && emp.isAtivo()) {
            emp.setAtivo(false);
            emp.getLivro().setDisponivel(true); // Devolve o livro pro acervo
            System.out.println("Devolucao concluida! O livro '" + emp.getLivro().getTitulo() + "' esta disponivel novamente.");
        } else {
            System.out.println("Registro de emprestimo ativo nao encontrado.");
        }
    }

    private int lerInteiro() {
        while (true) {
            try {
                return Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.print("Digite um codigo numerico: ");
            }
        }
    }
}