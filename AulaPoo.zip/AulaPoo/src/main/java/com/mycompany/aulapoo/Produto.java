package com.mycompany.aulapoo;

public class Produto {

    private String nome;
    private double preco;
    private int quantEmEstoque;

    public Produto(String nome, double preco, int quantEmEstoque) {
        this.nome = nome;
        this.preco = preco;
        this.quantEmEstoque = quantEmEstoque;
    }

    public void exibirInformacoes() {
        System.out.println("Nome: " + nome);
        System.out.println("Preço: " + preco);
        System.out.println("Estoque: " + quantEmEstoque);
    }
}
