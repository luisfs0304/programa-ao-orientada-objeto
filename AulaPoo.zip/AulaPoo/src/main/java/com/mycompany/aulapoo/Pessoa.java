package com.mycompany.aulapoo;

public class Pessoa {

    private String nome;
    private double altura;
    private String cpf;
    private int peso;
    private int idade;

    public Pessoa() {

    }

    public Pessoa(String nome, String cpf, double altura, int peso, int idade) {
        this.nome = nome;
        this.cpf = cpf;
        this.altura = altura;
        this.peso = peso;
        this.idade = idade;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public Pessoa(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
    }
        

    public void mostrarDados() {
        System.out.println("nome: " + nome + " idade:" + idade);
    }

}
