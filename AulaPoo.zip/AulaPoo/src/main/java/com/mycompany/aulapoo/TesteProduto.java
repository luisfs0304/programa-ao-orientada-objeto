package com.mycompany.aulapoo;

public class TesteProduto {
    public static void main(String[] args) {

        Produto p1 = new Produto("Monitor 24\" ", 900, 10);
        Produto p2 = new Produto("CPU", 300, 25);

        p1.exibirInformacoes();
        p2.exibirInformacoes();
    }
}
