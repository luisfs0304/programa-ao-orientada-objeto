/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aula4;

/**
 *
 * @author luis.albuquerque
 */
public class testeProduto {
     public static void main(String[] args) {

        // Criar dois produtos
        Produto p1 = new Produto("Monitor 24\"", 900, 10);
        Produto p2 = new Produto("CPU", 300, 25);
        Produto p3 = new Produto("Mouse", 30.5, 50);

        // Exibir informações
        p1.exibirInformacoes();
        System.out.println("************");

        p2.exibirInformacoes();
        System.out.println("************");

        p3.exibirInformacoes();
    }
    
}
